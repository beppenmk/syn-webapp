angular
  .module('app')
  .component('app', {
    templateUrl: 'app/main.html'
  });
