angular
  .module('app')
  .component('fountainTitle', {
    templateUrl: 'app/title.html'
  });
