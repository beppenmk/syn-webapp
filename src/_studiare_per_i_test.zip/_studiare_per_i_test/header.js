angular
  .module('app')
  .component('fountainHeader', {
    templateUrl: 'app/header.html'
  });
