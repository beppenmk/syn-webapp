angular
  .module('app')
  .component('fountainFooter', {
    templateUrl: 'app/footer.html'
  });
